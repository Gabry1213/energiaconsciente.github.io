# Hangman Game
### Overview

Using Javascript (JS), we programmed this game to generate random words that causes the user to guess the name of each candy by keying in the letters.

Lesson Discovery of the following:

- Variables
- Functions
- Conditionals
- Loops

