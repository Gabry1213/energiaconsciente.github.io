# Javascript Quiz com Multiplas Respostas

Exemplo de quiz com possibilidades de vários resultados de acordo com as resposta escolhidas pelo usuário feito com HTML, Javascript, Jquery e CSS



O script irá listar as perguntas e respostas do nosso questionário que está configurado no arquivo /quiz-multiplas-respostas/jsmultiplequiz.js
